package cs520.hw1; 
import javax.swing.JOptionPane;

public class Banking {

	public static void main(String[] args) {
		
        //input
		String input = JOptionPane.showInputDialog("Enter the amount");
		Integer amount = Integer.parseInt(input); //
		System.out.println("Requested Amount " + amount);
		Integer hundreds, fifties, twenties, tens, fives, twos, ones;
		
		//calculating hundreds
		hundreds = amount / 100; 
		Integer remainingAmount = amount - hundreds * 100;
		System.out.println("Hundreds = " + hundreds +", Remaining Amount = " + remainingAmount);
		
		//calculating fifties
		fifties = remainingAmount / 50; 
		remainingAmount -= fifties * 50;
		System.out.println("Fifties = " + fifties +", Remaining Amount = " + remainingAmount);
		
		//calculating twenties
		twenties = remainingAmount / 20;
		remainingAmount -= twenties * 20;
		System.out.println("Twenties = " + twenties + ", Remaining Amount = " + remainingAmount);
		
		//calculating tens
		tens = remainingAmount / 10;
		remainingAmount -= tens * 10;
		System.out.println("Tens = " + tens + ", Remaining Amount = " + remainingAmount);
		
		//calculating fives
		fives = remainingAmount / 5;
		remainingAmount -= fives * 5;
		System.out.println("Fives = " + fives + ", Remaining Amount = " + remainingAmount);
		
		//calculating twos
		twos = remainingAmount / 2;
		remainingAmount -= twos * 2;
		System.out.println("Twos = " + twos + ", Remaining Amount = " + remainingAmount);
		
		//calculating ones
		ones = remainingAmount;
		System.out.println("Ones = " + ones); 
	}
}
