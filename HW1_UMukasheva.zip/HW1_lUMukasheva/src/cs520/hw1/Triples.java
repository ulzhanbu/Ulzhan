package cs520.hw1;

public class Triples {

	public static void main(String[] args) {
		int i=0; // variable for count
		System.out.println("  Count    x     y     z");
		//loop to generate 1st number x
		for(int x=1; x<=100; x++) {
			//nested loop to generate 2nd number y
			for (int y=1; y<=100; y++){	
				//sum = x^2 + y^2
				double sum = Math.pow(x, 2) + Math.pow(y, 2);
				//convert square root of sum to integer 3rd number z
				int z = (int)(Math.sqrt(sum)); 
					//conditions
					if ((z*z ==(int)Math.round(sum)) && ((x<y)&&(y<z))){
					i+=1;
					//output
					System.out.printf("%5d) %5d %5d %5d", i,x,y,z);
					System.out.println();
					}
			}
		}
	}
}