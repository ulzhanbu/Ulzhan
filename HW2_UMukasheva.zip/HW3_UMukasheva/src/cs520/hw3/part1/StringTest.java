package cs520.hw3.part1;

import javax.swing.JOptionPane;

public class StringTest {

	public static void main(String[] args) {
		//Input data 
		String input = JOptionPane.showInputDialog("Please enter data using format CourseId,CourseName,Tuition");
		//Trim the user�s input
		input = input.trim();
		//Display result
		System.out.println(input);
		//Index of 1st comma
		int FirstComPos = input.indexOf(","); 
		//Result of CourseID
		System.out.println("First Comma Position:" + FirstComPos + ", Course Id:" + input.substring(0, FirstComPos)+ ", Length:" + input.substring(0, FirstComPos).length());
		//Index of 2nd comma
		int SecondComPos = input.indexOf(",", FirstComPos + 1);
		//Result of Course Name
	    System.out.println("Second Comma Position:" + SecondComPos + ", Course Name:" + input.substring(FirstComPos+1, SecondComPos)+ ", Length:" + input.substring(FirstComPos+1, SecondComPos).length());
	    //Extract the tuition
	    int RegularTuition = Integer.parseInt(input.substring(SecondComPos + 1, input.length()));
	    //Final result + discount
	    System.out.println("RegularTuition: $"+ RegularTuition + " Discount Tuition: $" + (int)(RegularTuition * 0.75));
	}

}
