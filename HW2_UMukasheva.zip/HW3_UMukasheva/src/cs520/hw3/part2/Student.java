package cs520.hw3.part2;

public class Student {

	private String name;
	private int homework1, homework2, homework3, homework4, homework5, homework6;
	
	//Student constructor 
	public Student(String Name) {
		this.name = Name;
	}
	//setter methods for HW 1-6
	public void setHomework1(int x) 
	{
		homework1 = x;
	};
	public void setHomework2(int x) 
	{
		homework2 = x;
	};
	public void setHomework3(int x) 
	{
		homework3 = x;
	};
	public void setHomework4(int x) 
	{
		homework4 = x;
	};
	public void setHomework5(int x) 
	{
		homework5 = x;
	};
	public void setHomework6(int x) 
	{
		homework6 = x;
	};
	//the average homework grade calculation
	public String computeAverage() 
	{
	double avg = (double)((homework1 + homework2 + homework3 + homework4 + homework5 + homework6) / 6.00);
	String result = String.format("%.2f", avg);
	return result;
	}
	//method to string representation of the object
	public String toString() 
	{
		return this.name + "�s average grade is " + computeAverage();
	}
}
