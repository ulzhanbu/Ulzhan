package cs520.hw3.part2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class Test {

	public static void main(String[] args) {
		String inputFileName = "data.txt";
		FileReader fileReader = null;
		//create the fileReader object
		try {
			fileReader = new FileReader (inputFileName);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		BufferedReader reader = new BufferedReader(fileReader);
		String input;
		//read 1 line at a time until the end
		try {
			input = reader.readLine();
			while (input != null) {
				processInputData(input);
				input = reader.readLine();
			}	
		} catch (IOException e) {
			e.printStackTrace();
		}
		//close the input
		try {
			fileReader.close();
		} catch (IOException e) {
			e.printStackTrace();}
		}

	private static void processInputData(String data) {
		StringTokenizer st = new StringTokenizer(data, ",");
		String name = st.nextToken();
		Student currentStudent = new Student(name);
		currentStudent.setHomework1(Integer.parseInt(st.nextToken()));
		currentStudent.setHomework2(Integer.parseInt(st.nextToken()));
		currentStudent.setHomework3(Integer.parseInt(st.nextToken()));
		currentStudent.setHomework4(Integer.parseInt(st.nextToken()));
		currentStudent.setHomework5(Integer.parseInt(st.nextToken()));
		currentStudent.setHomework6(Integer.parseInt(st.nextToken()));
		System.out.println(currentStudent.toString());
	}
}
