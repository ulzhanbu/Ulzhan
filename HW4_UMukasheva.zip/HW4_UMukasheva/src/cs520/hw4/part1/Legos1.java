package cs520.hw4.part1;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Graphics;

@SuppressWarnings("serial")
public class Legos1 extends JFrame {
	//variables for rectangle
	int startX, startY, legoHeight, legoWidth, baseLength;
	//Constructor
	public Legos1()
	{
		super("Mukasheva's LEGOs");
		//starting values
		startX = 20;
		startY = 300;
		legoWidth = 50;
		legoHeight = 20;
		baseLength = 10;
	}
	//drawing method
	public void paint(Graphics g)
	{
		int X=startX; //start position for each row
		for(int row = 0; row < baseLength; row++)	//level loop
		{
			//start position for each row
			startX += row*(this.legoWidth / 2);
				for(int lego = 0; lego < baseLength - row ; lego++)  //lego loop, number of legos decrease -1 
				{
					// choosing color
					if(lego % 2 == 0) g.setColor(Color.red);
						else g.setColor(Color.blue);
					//drawing a rectangle
					g.fillRoundRect(startX, startY, legoWidth, legoHeight, 2, 2);
					startX += this.legoWidth; // changing start position for the next lego in the row
				}
			//move to the next level
			startY-=this.legoHeight;
			//returning to the start position X
			startX=X;
		}
	}
	 public static void main(String[] args){
		  //window settings
	      Legos1 app = new Legos1();
	      app.setSize(550, 325);
	      app.setVisible(true);
	      app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
