package cs520.hw4.part1;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

@SuppressWarnings("serial")
public class Legos2 extends JFrame 
{
	int startX, startY, legoHeight, legoWidth, baseLength;
	//array for colors
	Color [] colorsarr = {Color.red, Color.blue, Color.yellow, Color.green, Color.pink, Color.black, Color.magenta, Color.orange, Color.cyan};
		
	public Legos2()
	{	
			super("Mukasheva's LEGOs2");
			startX = 20;
			startY = 300;
			legoWidth = 50;
			legoHeight = 20;
			baseLength = 10;
	}

	public void paint(Graphics g)
	{
		int X=startX; 
		for(int row = 0; row < baseLength; row++)
		{
			startX += row*(this.legoWidth / 2);
				for(int lego = 0; lego < baseLength - row ; lego++)
				{
					//random
					Random rndm = new Random();
					// fill each lego with a random color
					g.setColor(colorsarr[rndm.nextInt(colorsarr.length)]);
					g.fillRoundRect(startX, startY, legoWidth, legoHeight, 2, 2);
					startX += this.legoWidth;
				}
				startY-=this.legoHeight;
				startX=X;
			}
	}
		
	public static void main(String[] args) 
	{
		Legos2 gui = new Legos2();
		gui.setSize(550,325);
		gui.setVisible(true);
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}