package cs520.hw4.part1;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

@SuppressWarnings("serial")
public class Legos3 extends JFrame 
{

	int startX, startY, legoHeight, legoWidth, baseLength;
	Color [] colorsarr = {Color.red, Color.blue, Color.yellow, Color.green, Color.pink, Color.black, Color.magenta, Color.orange, Color.cyan};
	
	public Legos3()
	{
			super("Mukasheva's LEGOs3");
			startX = 20;
			startY = 300;
			legoWidth = 50;
			legoHeight = 20;
			baseLength = 10;
	}
	
	public void paint(Graphics g)
	{
		int X=startX;
		Color color1 = null;
		for(int row = 0; row < baseLength; row++)
		{
			startX += row*(this.legoWidth / 2);
				for(int lego = 0; lego < baseLength - row ; lego++)
				{
					Random rndm = new Random();
					//randomly find color
					Color color2 = colorsarr[rndm.nextInt(colorsarr.length)];
						//finding new color that not equal to previous 
						while(color2 == color1)
						{ 
						    color2 = colorsarr[rndm.nextInt(colorsarr.length)];
						} 
					//set the color to lego
					g.setColor(color2);
					g.fillRoundRect(startX, startY, legoWidth, legoHeight, 2, 2);
					// store the current color as the previous color to start over
					color1 = color2;
					startX += this.legoWidth;
				}
				startY-=this.legoHeight;
				startX=X;
			}
	}
	
	public static void main(String[] args) 
	{
		Legos3 gui = new Legos3();
		gui.setSize(550,325);
		gui.setVisible(true);
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
