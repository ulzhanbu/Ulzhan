package cs520.hw5;

import java.util.ArrayList;

public class Student {

	private String name;
	private ArrayList<Integer> homeworks;
	
	//student constructor
	public Student(String Name) {
		this.name = Name;
		homeworks = new ArrayList<Integer>();
	}
	//getter for student's name
	public String getName() {
		return name;
	}
	//setter for student's name
	public void setName(String Name) {
		this.name = Name;
	}
	public void addHomeworkGrade(int Grade) {
		homeworks.add(Grade);
	}	
	//the average homework grade calculation
	public double computeAverage() {
		double sum=0;
		for (int i=0; i<homeworks.size();i++) {
			sum += homeworks.get(i); 
		}
		return sum / homeworks.size();
	}
	//method to string representation of the object
	public String toString() 
	{
		return this.name + "�s average grade is " + String.format("%.2f", computeAverage());
	}
}
