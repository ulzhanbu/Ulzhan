package cs520.hw5;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

public class Test {

	public static void main(String[] args) {
		//list declaration
		List<Student> studentQueue = new LinkedList<Student>();
		//map declaration
		Map<String, Student> studentMap = new HashMap<String, Student>();
		//using input file data.txt
		String inputFileName = "data.txt";
		FileReader fileReader = null;
		//create the fileReader object
		try {
			fileReader = new FileReader (inputFileName);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		//using BufferedReader
		System.out.println("Input file processing...");
		BufferedReader reader = new BufferedReader(fileReader);
		String input;
		//read 1 line at a time until the end
		try {
			input = reader.readLine();
			while (input != null) {
				Student stdt = processInputData(input);
				input = reader.readLine();
				studentQueue.add(stdt);
				studentMap.put(stdt.getName(), stdt);
			}	
		} catch (IOException e) {
			e.printStackTrace();
		}
		//close the input
		try {
			fileReader.close();
		} catch (IOException e) {
			e.printStackTrace();}
				//using list
		System.out.println("\nIterating over the student list...");
		Iterator<Student> studentI = studentQueue.iterator();
		while (studentI.hasNext()) {
			System.out.println(studentI.next());
		}
				//using map
		System.out.println("\nIterating over the student map...");
		Set<String> nameK = studentMap.keySet();
		Iterator<String> nameI = nameK.iterator();
		while (nameI.hasNext()) {
			String name = nameI.next();
			System.out.println(studentMap.get(name));
		}
	}
	private static Student processInputData(String data) {
		StringTokenizer st = new StringTokenizer(data, ",");
		String name = st.nextToken();
		Student currentStudent = new Student(name);
		
		String token;
		int grade;
		while (st.hasMoreTokens()) {
			token = st.nextToken();
			grade = Integer.parseInt(token);
			currentStudent.addHomeworkGrade(grade);
		}
		System.out.println(currentStudent);
		return currentStudent;
	}
}

