package cs520.hw6;

class LongTask extends Thread {
	//instant variables
	private SharedResults sharedData;
	private int start, end;
	// constructor
	public LongTask(SharedResults sharedData, int start, int end) {
		this.sharedData = sharedData;
		this.start = start;
		this.end = end;
		//setting a name of the thread as Thread_<start>_<end>
		setName("Thread_"+String.valueOf(start)+"_"+String.valueOf(end));
	}
	@Override
	public void run() 
	{
		super.run();
		int sum=0;
		for(int i=start; i<=end; i++)
		{
			sum += i;
			try {
				// sleep in each iteration of the loop
				sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		//invoke addToResult method
		sharedData.addToResult_method(sum);
	}
}