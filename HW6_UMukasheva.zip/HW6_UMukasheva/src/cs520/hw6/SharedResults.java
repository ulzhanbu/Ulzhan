package cs520.hw6;

public class SharedResults {
	  //the instance private variable 
	  private int result;
	  // add to the result method
	  synchronized void addToResult_method(int result){
		  this.result+=result;
		  System.out.println(Thread.currentThread().getName() + " is adding " + result +", Cumulative Result is "+this.result);
	  }
	  //returns the shared result (with the synchronization)
	  synchronized int getResult(){
		  return this.result;
	  }
}
