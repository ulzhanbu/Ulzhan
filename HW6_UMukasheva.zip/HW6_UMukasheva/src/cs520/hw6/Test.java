package cs520.hw6;

public class Test {
    public static void main (String [] args) {
    	//new object
        SharedResults sr = new SharedResults();
        //array lt (contains 5 LongTask objects)
        LongTask [] lt = new LongTask[5];
        //array filling with  the start and end values
        for (int i = 0; i < 5; i++)
        {
            lt[i] = new LongTask(sr, i*100+1, (i+1)*100);
            lt[i].start();
        }
        for (int i = 0; i < 5; i++)
        {
        try {
           lt[i].join();
        	} catch (InterruptedException e) 
        		{
            System.out.println("Main thread Interrupted");
        		}
        }
        System.out.println ("Result " + sr.getResult());
    }
}
